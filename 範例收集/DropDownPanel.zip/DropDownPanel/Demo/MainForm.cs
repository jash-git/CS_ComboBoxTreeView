using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

using AT.STO.UI.Win;

namespace Demo
{
	public partial class MainForm : Form
	{
	#region Constructor / Destructor
		public MainForm()
		{
			InitializeComponent();
		}
	#endregion
	#region Form Events
		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad(e);
			InitializeDerived();
			InitializePanel();
		}
	#endregion
	#region Event Handler
		private void DropDown_FinishEditing(object sender, DropDownValueChangedEventArgs e)
		{
			LogEvent((sender as Control).Name + ".FinishEditing", e.Value);
		}
		
		private void DropDown_ValueChanged(object sender, DropDownValueChangedEventArgs e)
		{
			LogEvent((sender as Control).Name + ".ValueChanged", e.Value);
		}
	#endregion
	#region Private Methods
		/// <summary>
		/// Populates a given DropDownTree.
		/// </summary>
		/// <param name="Tree"></param>
		private void CreateNodes(DropDownTree Tree)
		{
			DropDownNode root = new DropDownNode(1, "1");
	
			Tree.Nodes.Clear();
			Tree.Nodes.Add(root);
			
			for (int i = 1; i <= 20; i++)
			{
				DropDownNode node = new DropDownNode(i * 1000, "1." + i.ToString("00"));
				root.Nodes.Add(node);
				
				for (int j = 1; j <= 2; j++)
				{
					node.Nodes.Add(new DropDownNode((i * 1000) + (j * 10),  "1." + i.ToString("00") + "." + j.ToString()));
				}
			}
			
			root.Expand();
		}
		
		private DropDownTree CreateTree()
		{
			DropDownTree tree = new DropDownTree();
			
			tree.BorderStyle = BorderStyle.None;				// border is drawn by the DropDownForm.
			tree.Size = new Size(200, 300);						// the DropDownPanel will be sized to make the tree fit.
			
			CreateNodes(tree);
			
			return tree;
		}
		
		/// <summary>
		/// Create and initialize the DerivedTreeCombo.
		/// </summary>
		private void InitializeDerived()
		{
			derivedTreeCombo.DropDownControl.Size = new Size(200, 300);
			CreateNodes(derivedTreeCombo.DropDownControl);
			
			derivedTreeCombo.FinishEditing += new DropDownValueChangedEventHandler(DropDown_FinishEditing);
			derivedTreeCombo.ValueChanged += new DropDownValueChangedEventHandler(DropDown_ValueChanged);
		}
		
		/// <summary>
		/// Create and initialize the DropDownTree.
		/// </summary>
		/// <returns></returns>
		private void InitializePanel()
		{
			treePanel.DropDownControl = CreateTree();			// make the DropDownTree the DropDownPanels control to display. 
			treePanel.FinishEditing += new DropDownValueChangedEventHandler(DropDown_FinishEditing);
			treePanel.ValueChanged += new DropDownValueChangedEventHandler(DropDown_ValueChanged);
		}
		
		private void LogEvent(string Event, object Value)
		{
			if (txtMsg.Lines.Length > 20)
			{
				txtMsg.Clear();
			}
		
			txtMsg.AppendText(Event + ": " + ((Value == null) ? "user canceled" : Value.ToString()) + "\r\n");
		}
	#endregion
	}
}