namespace Demo
{
	partial class MainForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.onTheFlyBox = new System.Windows.Forms.GroupBox();
			this.treePanel = new AT.STO.UI.Win.DropDownPanel();
			this.txtMsg = new System.Windows.Forms.TextBox();
			this.derivedPanel = new System.Windows.Forms.GroupBox();
			this.derivedTreeCombo = new Demo.DerivedTreeCombo();
			this.onTheFlyBox.SuspendLayout();
			this.derivedPanel.SuspendLayout();
			this.SuspendLayout();
			// 
			// onTheFlyBox
			// 
			this.onTheFlyBox.Controls.Add(this.treePanel);
			this.onTheFlyBox.Location = new System.Drawing.Point(12, 12);
			this.onTheFlyBox.Name = "onTheFlyBox";
			this.onTheFlyBox.Size = new System.Drawing.Size(171, 71);
			this.onTheFlyBox.TabIndex = 1;
			this.onTheFlyBox.TabStop = false;
			this.onTheFlyBox.Text = "create control on the fly";
			// 
			// treePanel
			// 
			this.treePanel.Location = new System.Drawing.Point(21, 31);
			this.treePanel.Name = "treePanel";
			this.treePanel.Size = new System.Drawing.Size(124, 21);
			this.treePanel.TabIndex = 1;
			// 
			// txtMsg
			// 
			this.txtMsg.AcceptsReturn = true;
			this.txtMsg.Anchor = ((System.Windows.Forms.AnchorStyles) ((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
						| System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.txtMsg.Location = new System.Drawing.Point(3, 175);
			this.txtMsg.Multiline = true;
			this.txtMsg.Name = "txtMsg";
			this.txtMsg.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.txtMsg.Size = new System.Drawing.Size(464, 152);
			this.txtMsg.TabIndex = 2;
			// 
			// derivedPanel
			// 
			this.derivedPanel.Controls.Add(this.derivedTreeCombo);
			this.derivedPanel.Location = new System.Drawing.Point(12, 89);
			this.derivedPanel.Name = "derivedPanel";
			this.derivedPanel.Size = new System.Drawing.Size(171, 71);
			this.derivedPanel.TabIndex = 4;
			this.derivedPanel.TabStop = false;
			this.derivedPanel.Text = "derived control";
			// 
			// derivedTreeCombo
			// 
			this.derivedTreeCombo.Location = new System.Drawing.Point(21, 31);
			this.derivedTreeCombo.Name = "derivedTreeCombo";
			this.derivedTreeCombo.Size = new System.Drawing.Size(124, 21);
			this.derivedTreeCombo.TabIndex = 4;
			this.derivedTreeCombo.Value = null;
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(467, 331);
			this.Controls.Add(this.derivedPanel);
			this.Controls.Add(this.txtMsg);
			this.Controls.Add(this.onTheFlyBox);
			this.Name = "MainForm";
			this.Text = "Main";
			this.onTheFlyBox.ResumeLayout(false);
			this.derivedPanel.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.GroupBox onTheFlyBox;
		private AT.STO.UI.Win.DropDownPanel treePanel;
		private System.Windows.Forms.TextBox txtMsg;
		private System.Windows.Forms.GroupBox derivedPanel;
		private DerivedTreeCombo derivedTreeCombo;
	}
}

